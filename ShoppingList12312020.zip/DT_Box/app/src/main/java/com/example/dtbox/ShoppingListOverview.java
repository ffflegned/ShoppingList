package com.example.dtbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ShoppingListOverview extends AppCompatActivity implements ItemRecyclerViewAdapter.ClickListener{
    private FirebaseDatabase mDataBase;
    private DatabaseReference mRef;
    private String userEmail;
    private FirebaseAuth mAuth;
    public static int clickedPos;
    final ArrayList<String> stringList = new ArrayList<String>();

    String id;
    public ArrayList<String> firebaseList= new ArrayList<String>();
    RecyclerView recyclerViewShoppingListOverview;
    ListRecyclerViewAdapter adapter = new ListRecyclerViewAdapter(stringList,this);
    //respond to menu item selection,add
    private SearchView searchView;
    public boolean onCreateOptionsMenu(Menu menu) {
        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.notepad_menu,menu);
        MenuItem searchItem = menu.findItem(R.id.search);
        searchView = (SearchView)searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String newText) {
                ListRecyclerViewAdapter adapter = new ListRecyclerViewAdapter(stringList, new ItemRecyclerViewAdapter.ClickListener() {
                    @Override
                    public void onItemClick(int position) {

                    }

                    @Override
                    public boolean onItemLongClick(int position) {
                        return false;
                    }
                });
                adapter.getFilter().filter(newText);
                recyclerViewShoppingListOverview.setAdapter(adapter);
                searchView.setQuery("", false);;
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                final String tempS = newText;
                if(newText.isEmpty())
                {
                    initializeData();
                }

                mRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        stringList.clear();
                        for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            String temp  =postSnapshot.child("ListName").getValue(String.class);
                            stringList.add(temp);
                        }
                        //at this point you have looped through all the "children" -
                        //now you are ready to initialize the adapter


                        recyclerViewShoppingListOverview.setAdapter(adapter);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }


                });


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        final ListRecyclerViewAdapter d = new ListRecyclerViewAdapter(stringList, new ItemRecyclerViewAdapter.ClickListener() {
                            @Override
                            public void onItemClick(int position) {

                            }

                            @Override
                            public boolean onItemLongClick(int position) {
                                return false;
                            }
                        });


                        d.getFilter().filter(tempS);
                        recyclerViewShoppingListOverview.setAdapter(d);
                    }
                },1000);
                return false;
            }
        });

        searchItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                searchView.clearFocus();
                initializeData();

                return true;
            }
        });
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.search) {
            searchView.setIconifiedByDefault(true);
            searchView.setFocusable(true);
            searchView.setIconified(false);
            searchView.setQuery("", false);
            searchView.requestFocusFromTouch();
        }
        if(id == R.id.addNoteOption)
        {
            addItemDialog();
        }

        return super.onOptionsItemSelected(item);
    }
///////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list_overview);
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        mDataBase = FirebaseDatabase.getInstance();
        mRef = mDataBase.getReference();
        userEmail = mUser.getEmail();
        userEmail = userEmail.substring(0,userEmail.indexOf("@"));
        mRef.keepSynced(true);
        mRef = mRef.child("Shopping List").child(userEmail);
        mRef.keepSynced(true);
        recyclerViewShoppingListOverview = (RecyclerView) findViewById(R.id.recycler_view_shopping_list_overview);
        LinearLayoutManager recyclerViewLayoutManager = new LinearLayoutManager(this);
        recyclerViewShoppingListOverview.setHasFixedSize(true);
        recyclerViewShoppingListOverview.setLayoutManager(recyclerViewLayoutManager);

        initializeData();
        TextView addItemTextPrompt = (TextView)findViewById(R.id.overview_add_item_textView);
        addItemTextPrompt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItemDialog();
            }
        });



    }
///////////////////////////////////

    private void addItemDialog() {
        firebaseList.clear();
        getListID();
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingListOverview.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingListOverview.this);
        View editView = inflater.inflate(R.layout.list_editor_layout, null);
        final AlertDialog dialog = myDialog.create();
        dialog.setView(editView);
        dialog.show();
        final EditText listName = editView.findViewById(R.id.add_list);
        Button save = editView.findViewById(R.id.overview_save_button);
        Button cancel = editView.findViewById(R.id.overview_cancel_button);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ListName = listName.getText().toString().trim();
                if (TextUtils.isEmpty(ListName)) {
                    listName.setError("Required Field Type");
                    return;
                }
                id = mRef.push().getKey();
               mRef.child(id).child("ListName").setValue(ListName);

                Toast.makeText(getApplicationContext(), "Data Added", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        }
    //////////////////////////////////////////////////////////////



        private void updateItemDialog(int position) {
        firebaseList.clear();
        getListID();
        final int POSITION = position;
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingListOverview.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingListOverview.this);
        View editView = inflater.inflate(R.layout.update_list_editor_layout, null);

        final AlertDialog dialog = myDialog.create();
        dialog.setView(editView);
        dialog.show();
        final EditText update_type = (EditText) editView.findViewById(R.id.update_list);
        final Button update_save_button = (Button)editView.findViewById(R.id.overview_udpate_button);
        final Button update_cancel_button = (Button) editView.findViewById(R.id.overview_cancel_update_button);

        update_save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mType = update_type.getText().toString().trim();

                if (TextUtils.isEmpty(mType)) {
                    update_type.setError("Required Field Type");
                    return;
                }
                mRef.child(firebaseList.get(POSITION)).child("ListName").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        ArrayList<String> firebaseList= new ArrayList<String>();
                        for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                           String temp  =postSnapshot.getValue(String.class);
                            firebaseList.add(temp);
                        }
                        for(String temp:firebaseList)
                        {
                            update_type.setText(temp);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
                mRef.child(firebaseList.get(POSITION)).child("ListName").setValue(mType);
                Toast.makeText(getApplicationContext(), "Data Updated", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        update_cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
    private void initializeData(){
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                stringList.clear();
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    String temp  =postSnapshot.child("ListName").getValue(String.class);
                    stringList.add(temp);
                }
                recyclerViewShoppingListOverview.setAdapter(adapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    public void onItemClick(int position) {
        clickedPos = position;
        Intent intent=new Intent(ShoppingListOverview.this, ShoppingList.class);
        startActivity(intent);
    }

    @Override
    public boolean onItemLongClick(int position) {
        final int POSITION = position;
        firebaseList.clear();
        getListID();
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingListOverview.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingListOverview.this);
        View editView = inflater.inflate(R.layout.click_dialog, null);
        final AlertDialog OverallDialog = myDialog.create();
        OverallDialog.setView(editView);
        OverallDialog.show();
        final Button update_button = (Button)editView.findViewById(R.id.click_dialog_update);
        final Button delete_button = (Button) editView.findViewById(R.id.click_dialog_delete);
        final Button update_image_button = (Button) editView.findViewById(R.id.click_dialog_update_image);
        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItemDialog(POSITION);
                OverallDialog.dismiss();
            }
        });
        update_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ShoppingListOverview.this, UpdateImage.class);
                startActivity(intent);

            }
        });

        delete_button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(ShoppingListOverview.this);
                alert.setMessage("Are you sure you want to delete?");
                alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {


                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                        mRef.keepSynced(true);
                        Toast.makeText(getApplicationContext(),firebaseList.get(POSITION), Toast.LENGTH_SHORT).show();
                        mRef.child(firebaseList.get(POSITION)).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {

                                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();

                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
                        firebaseList.remove(POSITION);

                        OverallDialog.dismiss();

                    }
                });

                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // close dialog
                        dialog.cancel();
                    }
                });
                alert.show();

            }
        });

        return false;
    }
    public void getListID()
    {
        mRef.keepSynced(true);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    String temp  =postSnapshot.getKey();
                    firebaseList.add(temp);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });

    }
}