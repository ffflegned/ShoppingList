package com.example.dtbox;


import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dtbox.Model.Data;

import java.util.ArrayList;

public class CrossedOffItemRecyclerViewAdapter extends RecyclerView.Adapter<CrossedOffItemRecyclerViewAdapter.CrossedOffItemViewHolder> {
    static ArrayList<Data> mCrossedOffDataList;
    CrossedOffClickListener mClickListener;




    CrossedOffItemRecyclerViewAdapter(ArrayList<Data> list, CrossedOffClickListener clickListener) {
        mCrossedOffDataList = list;
        mClickListener = clickListener;


    }


    public static class CrossedOffItemViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener,View.OnClickListener{
        View mView;
        CrossedOffClickListener clickListener;

        public CrossedOffItemViewHolder(View v,CrossedOffClickListener clickListener) {
            super(v);
            mView = v;
            this.clickListener = clickListener;
            v.setOnLongClickListener(this);
            v.setOnClickListener(this);

        }

        public void setType(String Type) {
            TextView mType = mView.findViewById(R.id.type_display);
            mType.setPaintFlags(mType.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            mType.setText(Type);
        }
        public void setSpec(String Spec) {
            TextView mType = mView.findViewById(R.id.spec_display);
            //mType.setPaintFlags(mType.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            mType.setText(Spec);
        }

        public void setCount(double Count) {
            String sCount = String.valueOf(Count);
            TextView mCount = mView.findViewById(R.id.count_display);
            mCount.setPaintFlags(mCount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            mCount.setText(sCount);
        }

        public void setPrice(double Price) {
            String sPrice = Double.toString(Price);
            String finalPrice = "$" + sPrice;
            TextView mPrice = mView.findViewById(R.id.price_display);
            mPrice.setPaintFlags(mPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            mPrice.setText(finalPrice);
        }
        public void setTotalPrice(double totalPrice) {
            String sPrice = Double.toString(totalPrice);
            String finalPrice = "$" + sPrice;
            //TextView mTotalPrice = mView.findViewById(R.id.totalPrice_display);
            //mTotalPrice.setPaintFlags(mTotalPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            //mTotalPrice.setText(finalPrice);
        }

        @Override
        public void onClick(View v) {

            clickListener.onCrossedOffItemClick(getAdapterPosition());

        }

        @Override
        public boolean onLongClick(View v) {

            return false;
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public CrossedOffItemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View textView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_data_layout, viewGroup, false);
        CrossedOffItemViewHolder vh = new CrossedOffItemViewHolder(textView,mClickListener);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull CrossedOffItemViewHolder vh, int position) {
        Data model = mCrossedOffDataList.get(position);
        vh.setType(model.getType());
        vh.setCount(model.getCount());
        vh.setPrice(model.getPrice());
        //vh.setTotalPrice(model.getTotalPrice());
        vh.setSpec(model.getSpec());
    }

    @Override
    public int getItemCount() {
        return mCrossedOffDataList.size();

    }
    public interface CrossedOffClickListener {
        void onCrossedOffItemClick(int position);
        boolean onCrossedOffItemLongClick(int position);
    }


}
