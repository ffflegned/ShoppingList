package com.example.dtbox;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dtbox.Model.Data;

import java.util.ArrayList;

public class ListRecyclerViewAdapter extends RecyclerView.Adapter<ListRecyclerViewAdapter.listViewHolder> implements Filterable {
    static ArrayList<String> mStringListSearched;
    static ArrayList<String> mStringList;
    ItemRecyclerViewAdapter.ClickListener mClickListener;

    ListRecyclerViewAdapter(ArrayList<String> list, ItemRecyclerViewAdapter.ClickListener clickListener) {
        mStringListSearched = list;
        mClickListener = clickListener;
        mStringList = new ArrayList<>();
        mStringList.addAll(list);

    }

    @Override
    public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    ArrayList<String> searchedList = new ArrayList<>();
                    if (constraint == null || constraint.length()==0)
                    {
                        Log.d("COUNT",Integer.toString(mStringList.size()));
                        searchedList.addAll(mStringList);
                    }
                    else
                    {
                        String match = constraint.toString().toLowerCase().trim();
                        for(String model:mStringList)
                        {
                            if(model.toLowerCase().contains(match))
                            {
                                searchedList.add(model);
                            }
                        }
                    }
                    FilterResults results = new FilterResults();
                    results.values = searchedList;
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    mStringListSearched.clear();
                    mStringListSearched.addAll((ArrayList<String>)results.values);
                    notifyDataSetChanged();
                }
            };

    }

    public static class listViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener, View.OnClickListener {
        private View mView;
        ItemRecyclerViewAdapter.ClickListener clickListener;

        public listViewHolder(View v, ItemRecyclerViewAdapter.ClickListener clickListener) {
            super(v);
            mView = v;
            this.clickListener = clickListener;
            v.setOnLongClickListener(this);
            v.setOnClickListener(this);

        }

        public void setList(String Type) {
            TextView mList = mView.findViewById(R.id.list_display);
            mList.setText(Type);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            String name = mStringListSearched.get(position);
            for (int i=0 ; i <mStringList.size() ; i++ ){
                if(name.equals(mStringList.get(i))){
                    position = i;
                    break;
                }
            }
            clickListener.onItemClick(position);
        }

        @Override
        public boolean onLongClick(View v) {
                int position = getAdapterPosition();
                String name = mStringListSearched.get(position);
                for (int i=0 ; i <mStringList.size() ; i++ ){
                    if(name.equals(mStringList.get(i))){
                        position = i;
                        break;
                    }
                }
            clickListener.onItemLongClick(position);
            return false;
        }

    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public ListRecyclerViewAdapter.listViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View textView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_overview_layout, viewGroup, false);
        ListRecyclerViewAdapter.listViewHolder vh = new ListRecyclerViewAdapter.listViewHolder(textView, mClickListener);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ListRecyclerViewAdapter.listViewHolder vh, int position) {
        String model = mStringListSearched.get(position);
        vh.setList(model);


    }

    @Override
    public int getItemCount() {
        return mStringListSearched.size();
    }

}
