package com.example.dtbox;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dtbox.Model.Data;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static com.example.dtbox.ShoppingListOverview.clickedPos;

public class ShoppingList extends AppCompatActivity implements ItemRecyclerViewAdapter.ClickListener, CrossedOffItemRecyclerViewAdapter.CrossedOffClickListener {
    private FirebaseDatabase mDataBase;
    private DatabaseReference mRef;
    private String id;
    private String userEmail;
    private String recordID_update;
    private FirebaseAuth mAuth;
    double grandTotal;
    static ArrayList <Data> recordList = new ArrayList<Data>();
    final ArrayList <Data> crossedOffRecordList = new ArrayList<Data>();
    final ArrayList <Data> temporaryRecordList = new ArrayList<>();
    final ArrayList <String> ListID = new ArrayList<>();
    public ArrayList<String> temporaryRecordIDList= new ArrayList<String>();
    public ArrayList<String> temporaryCrossedOffRecordIDList= new ArrayList<String>();
    public ArrayList<Data> temporaryCrossedOffRecordList = new ArrayList<Data>();
    RecyclerView recyclerViewShoppingList;
    ItemRecyclerViewAdapter adapter =  new ItemRecyclerViewAdapter(recordList,this);
    RecyclerView recyclerViewCrossedOffShoppingList;
    CrossedOffItemRecyclerViewAdapter crossedOffAdapter = new CrossedOffItemRecyclerViewAdapter(crossedOffRecordList,this);
    private SearchView searchView;

    //respond to menu item selection,add
           public boolean onCreateOptionsMenu(Menu menu) {

            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.notepad_menu,menu);
               MenuItem searchItem = menu.findItem(R.id.search);
            searchView = (SearchView)searchItem.getActionView();
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String newText) {
                    final String tempS = newText;
                    mRef.child("Records").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            recordList.clear();
                            for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                Data temp  =postSnapshot.getValue(Data.class);

                                recordList.add(temp);
                            }
                            //at this point you have looped through all the "children" -
                            //now you are ready to initialize the adapter



                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }


                    });


                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            final ItemRecyclerViewAdapter d = new ItemRecyclerViewAdapter(recordList, new ItemRecyclerViewAdapter.ClickListener() {
                                @Override
                                public void onItemClick(int position) {

                                }

                                @Override
                                public boolean onItemLongClick(int position) {
                                    return false;
                                }
                            });


                            d.getFilter().filter(tempS);
                            recyclerViewShoppingList.setAdapter(d);
                            searchView.setQuery("", false);
                        }
                    },1000);

                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    if(newText.isEmpty())
                    {
                        initializeData();
                    }
                    final String tempS = newText;
                    mRef.child("Records").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            recordList.clear();
                            for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                Data temp  =postSnapshot.getValue(Data.class);

                                recordList.add(temp);
                            }
                            //at this point you have looped through all the "children" -
                            //now you are ready to initialize the adapter



                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }


                    });


                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            final ItemRecyclerViewAdapter d = new ItemRecyclerViewAdapter(recordList, new ItemRecyclerViewAdapter.ClickListener() {
                                @Override
                                public void onItemClick(int position) {

                                }

                                @Override
                                public boolean onItemLongClick(int position) {
                                    return false;
                                }
                            });


                            d.getFilter().filter(tempS);
                            recyclerViewShoppingList.setAdapter(d);
                        }
                    },1000);
                    return false;
                }
            });

            searchItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
                @Override
                public boolean onMenuItemActionExpand(MenuItem item) {
                    return true;
                }

                @Override
                public boolean onMenuItemActionCollapse(MenuItem item) {
                    initializeData();
                    searchView.clearFocus();
                    return true;
                }
            });


               return true;

        }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.search) {
            getRecordList();
            ItemRecyclerViewAdapter adapter = new ItemRecyclerViewAdapter(recordList,this);
            searchView.setIconifiedByDefault(true);
            searchView.setFocusable(true);
            searchView.setIconified(false);
            searchView.setQuery("", false);
            searchView.requestFocusFromTouch();
        }
        if(id == R.id.addNoteOption)
        {
            addItemDialog();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);
        //setting up recycler view with arraylist as input and each element of array list will be displayed





        mAuth = FirebaseAuth.getInstance();
        FirebaseUser mUser = mAuth.getCurrentUser();
        //Uid = mUser.getUid();

        mDataBase = FirebaseDatabase.getInstance();
        mRef = mDataBase.getReference();
        userEmail = mUser.getEmail();
        userEmail = userEmail.substring(0,userEmail.indexOf("@"));
        recyclerViewShoppingList = (RecyclerView) findViewById(R.id.recycler_view_shopping_list);
        recyclerViewShoppingList.setHasFixedSize(true);
        LinearLayoutManager recyclerViewLayoutManager = new LinearLayoutManager(this);

        recyclerViewShoppingList.setHasFixedSize(true);
        recyclerViewShoppingList.setLayoutManager(recyclerViewLayoutManager);

        recyclerViewCrossedOffShoppingList = (RecyclerView) findViewById(R.id.recycler_view_shopping_list_crossed_off);
        recyclerViewCrossedOffShoppingList.setHasFixedSize(true);
        LinearLayoutManager crossedOffRecyclerViewLayoutManager = new LinearLayoutManager(this);

        recyclerViewCrossedOffShoppingList.setHasFixedSize(true);
        recyclerViewCrossedOffShoppingList.setLayoutManager(crossedOffRecyclerViewLayoutManager);
        getListKeys();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false); // if you want user to wait for some process to finish,
        builder.setView(R.layout.loading_dialog);
        final AlertDialog dialog = builder.create();
        dialog.show();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                dialog.dismiss();
                Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();

                mRef = mRef.child("Shopping List").child(userEmail).child(ListID.get(clickedPos)).child("Items");
                initializeData();



                TextView addItemTextPrompt = (TextView) findViewById(R.id.add_item_textView);
                addItemTextPrompt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addItemDialog();
                        initializeData();

                    }
                });
                ImageButton crossOffAll=(ImageButton)findViewById(R.id.cross_off_all_button);
                crossOffAll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        initializeData();
                    }
                });

            }
        }, 500);


            mRef.keepSynced(true);



    }





    private void addItemDialog() {
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingList.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingList.this);
        View editView = inflater.inflate(R.layout.activity_item_editor, null);
        final AlertDialog dialog = myDialog.create();
        dialog.setView(editView);
        dialog.show();
        final EditText type = editView.findViewById(R.id.type);
        final EditText spec = editView.findViewById(R.id.spec);
        final EditText count = editView.findViewById(R.id.count);
        final EditText price = editView.findViewById(R.id.price);
        count.setText("1");
        price.setText("0");
        Button save = editView.findViewById(R.id.save_button);
        Button cancel = editView.findViewById(R.id.cancel_button);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mType = type.getText().toString().trim();
                String mSpec = spec.getText().toString().trim();
                String Count = count.getText().toString().trim();
                double mCount = Double.parseDouble(Count);
                String Price = price.getText().toString().trim();
                double mPrice = Double.parseDouble(Price);
                double mTotalPrice = mCount*mPrice;

                if (TextUtils.isEmpty(mType)) {
                    type.setError("Required Field Type");
                    return;
                }

                if (TextUtils.isEmpty(Count)) {
                    count.setError("Required Field Count");
                    return;
                }
                if (TextUtils.isEmpty(Price)) {
                    price.setError("Required Field Price");
                    return;
                }
                id = mRef.push().getKey();
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                String mDate = dateFormat.format(date);
                Data data = new Data(mType,mSpec, mCount, mPrice, mDate, mTotalPrice);
                mRef.child("Records").child(id).setValue(data);
                Toast.makeText(getApplicationContext(), "Data Added", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                getGrandTotalPrice();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }

    private void updateItemDialog(int position) {
        final int POSITION = position;
        temporaryRecordList.clear();
        temporaryRecordIDList.clear();
        getRecordList();
        getRecordIDList();
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingList.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingList.this);
        View editView = inflater.inflate(R.layout.activity_update_item, null);
        final EditText update_type = (EditText) editView.findViewById(R.id.update_type);
        final EditText update_spec = (EditText) editView.findViewById(R.id.update_spec);
        final EditText update_count = (EditText) editView.findViewById(R.id.update_count);
        final EditText update_price = (EditText) editView.findViewById(R.id.update_price);
        final TextView update_sub_total = (TextView)editView.findViewById(R.id.update_total_price);
        final Button update_save_button = (Button)editView.findViewById(R.id.update_button);
        final Button update_cancel_button = (Button) editView.findViewById(R.id.update_cancel_button);
        final AlertDialog dialog = myDialog.create();
        dialog.setView(editView);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                dialog.show();
                update_type.setText(temporaryRecordList.get(POSITION).getType());
                update_spec.setText(temporaryRecordList.get(POSITION).getSpec());
                update_count.setText(String.valueOf(temporaryRecordList.get(POSITION).getCount()));
                update_price.setText(String.valueOf(temporaryRecordList.get(POSITION).getPrice()));
                DecimalFormat df = new DecimalFormat("0.00");
                update_sub_total.setText("Sub Total: $"+df.format(temporaryRecordList.get(POSITION).getTotalPrice()));
                recordID_update = temporaryRecordIDList.get(POSITION);
                update_save_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String mType = update_type.getText().toString().trim();
                        String mSpec = update_spec.getText().toString().trim();
                        String Count = update_count.getText().toString().trim();
                        double mCount = Double.parseDouble(Count);
                        String Price = update_price.getText().toString().trim();
                        double mPrice = Double.parseDouble(Price);
                        double mTotalPrice = mPrice*mCount;
                        if (TextUtils.isEmpty(mType)) {
                            update_type.setError("Required Field Type");
                            return;
                        }

                        if (TextUtils.isEmpty(Count)) {
                            update_count.setError("Required Field Count");
                            return;
                        }
                        if (TextUtils.isEmpty(Price)) {
                            update_price.setError("Required Field Price");
                            return;
                        }

                        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                        Date date = new Date();
                        String mDate = dateFormat.format(date);
                        Toast.makeText(getApplicationContext(), mDate, Toast.LENGTH_SHORT).show();
                        Data data = new Data(mType,mSpec, mCount, mPrice, mDate, mTotalPrice);
                        mRef.child("Records").child(recordID_update).setValue(data);
                        Toast.makeText(getApplicationContext(), "Data Updated", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        getGrandTotalPrice();


                    }
                });

            }
        }, 500);

        update_cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

    }










    private void initializeData(){
        getGrandTotalPrice();
        mRef.child("Records").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                recordList.clear();
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Data temp  =postSnapshot.getValue(Data.class);

                    recordList.add(temp);
                }
                //at this point you have looped through all the "children" -
                //now you are ready to initialize the adapter

                recyclerViewShoppingList.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });



        crossedOffRecordList.clear();
        crossedOffAdapter = new CrossedOffItemRecyclerViewAdapter(crossedOffRecordList,this);
        mRef.child("CrossedOffRecords").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                crossedOffRecordList.clear();
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Data temp  =postSnapshot.getValue(Data.class);

                    crossedOffRecordList.add(temp);
                }
                //at this point you have looped through all the "children" -
                //now you are ready to initialize the adapter

                recyclerViewCrossedOffShoppingList.setAdapter(crossedOffAdapter);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });

    }







    @Override
    public void onItemClick(int position) {
        final int POSITION = position;
        temporaryRecordList.clear();
        temporaryRecordIDList.clear();
        getRecordList();
        getRecordIDList();
        mRef.keepSynced(true);
        id = mRef.push().getKey();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                mRef.child("CrossedOffRecords").child(id).setValue(temporaryRecordList.get(POSITION));
                mRef.child("Records").child(temporaryRecordIDList.get(POSITION)).removeValue();
                getGrandTotalPrice();
        }
        }, 500);
    }

    @Override
    public boolean onItemLongClick(int position) {
        final int POSITION = position;
        temporaryRecordIDList.clear();
        getRecordIDList();
        AlertDialog.Builder myDialog = new AlertDialog.Builder(ShoppingList.this);
        LayoutInflater inflater = LayoutInflater.from(ShoppingList.this);
        View editView = inflater.inflate(R.layout.click_dialog, null);
        final AlertDialog OverAllDialog = myDialog.create();
        OverAllDialog.setView(editView);
        OverAllDialog.show();
        final Button update_button = (Button)editView.findViewById(R.id.click_dialog_update);
        final Button delete_button = (Button) editView.findViewById(R.id.click_dialog_delete);
        final Button update_image_button = (Button) editView.findViewById(R.id.click_dialog_update_image);
        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItemDialog(POSITION);



                OverAllDialog.dismiss();

            }
        });
        update_image_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ShoppingList.this, UpdateImage.class);
                startActivity(intent);

            }
        });

        delete_button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                AlertDialog.Builder deleteAlert = new AlertDialog.Builder(ShoppingList.this);
                //alert.setTitle("Delete entry");
                deleteAlert.setMessage("Are you sure you want to delete?");
                deleteAlert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        mRef.keepSynced(true);

                        mRef.child("Records").child(temporaryRecordIDList.get(POSITION)).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {

                                    Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();

                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
                        temporaryRecordIDList.remove(POSITION);
                        dialog.dismiss();
                        OverAllDialog.dismiss();
                        getGrandTotalPrice();
                    }
                });
                deleteAlert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // close dialog
                        OverAllDialog.dismiss();
                        dialog.cancel();
                        OverAllDialog.dismiss();
                    }
                });
                deleteAlert.show();

            }
        });




        return false;
    }
    public void getRecordList() {
        mRef.child("Records").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Data temp = postSnapshot.getValue(Data.class);
                    temporaryRecordList.add(temp);
                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
    }

    public void getRecordIDList() {
        mRef.keepSynced(true);
        mRef.child("Records").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    String temp = postSnapshot.getKey();
                    temporaryRecordIDList.add(temp);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
    }
        public void getCrossedOffRecordIDList() {
        mRef.child("CrossedOffRecords").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    String temp = postSnapshot.getKey();
                    temporaryCrossedOffRecordIDList.add(temp);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
    }
   public void getCrossedOffRecordList() {
       mRef.child("CrossedOffRecords").addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(DataSnapshot dataSnapshot) {

               for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                   Data temp = postSnapshot.getValue(Data.class);
                   temporaryCrossedOffRecordList.add(temp);
               }

           }


           @Override
           public void onCancelled(@NonNull DatabaseError error) {

           }


       });
   }


    public void getListKeys()
    {
        ListID.clear();
       FirebaseDatabase tempDataBase;
       DatabaseReference tempRef;
        tempDataBase = FirebaseDatabase.getInstance();
        tempRef = tempDataBase.getReference();
        tempRef = tempRef.child("Shopping List").child(userEmail);
        tempRef.keepSynced(true);
        tempRef.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                for(DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    String temp  =postSnapshot.getKey();
                    ListID.add(temp);
                }}
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });

    }


    @Override
    public void onCrossedOffItemClick(int position) {
        final int POSITION = position;
        temporaryCrossedOffRecordIDList.clear();
        temporaryCrossedOffRecordList.clear();
        getCrossedOffRecordIDList();
        getCrossedOffRecordList();
        mRef.keepSynced(true);
        id = mRef.push().getKey();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                mRef.child("Records").child(id).setValue(temporaryCrossedOffRecordList.get(POSITION));
                mRef.child("CrossedOffRecords").child(temporaryCrossedOffRecordIDList.get(POSITION)).removeValue();
                getGrandTotalPrice();
            }
        }, 500);





    }

    @Override
    public boolean onCrossedOffItemLongClick(int position) {
        return false;
    }
    public void getGrandTotalPrice()
    {
            grandTotal=0;
            recordList.clear();
            getRecordList();
            new Handler().postDelayed(new Runnable() {
                public void run() {

                    for(Data d:recordList)
                    {
                        grandTotal = grandTotal+d.getTotalPrice();
                    }
                    TextView grandTotalDisplay = findViewById(R.id.grand_total_price);
                            DecimalFormat df = new DecimalFormat("0.00");
                            String sGrandTotal = df.format(grandTotal);
                            grandTotalDisplay.setText("Total Price: $"+sGrandTotal);
                }
            }, 500);
    }







}

