package com.example.dtbox.Model;

public class Data {
    String type;
    String spec;
    double count;
    double price;
    String date;
    double totalPrice;
    public Data(){}
    public Data(String type, String spec, double count, double price, String date, double totalPrice) {
        this.type = type;
        this.spec = spec;
        this.count = count;
        this.price = price;
        this.date = date;
        this.totalPrice = totalPrice;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public String getSpec() {
        return spec;
    }
    public void setSpec(String spec) {
        this.spec = spec;
    }


    public double getCount() {
        return count;
    }

    public void setCount(double count) {
        this.count = count;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public String getDate()
    {
        return date;
    }
    public void setDate(String date)
    {
        this.date = date;
    }


    public double getTotalPrice() {
        return totalPrice;
    }

    public void setId(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
