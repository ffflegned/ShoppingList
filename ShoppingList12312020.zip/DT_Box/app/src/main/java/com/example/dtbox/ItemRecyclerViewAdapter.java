package com.example.dtbox;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dtbox.Model.Data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ItemRecyclerViewAdapter extends RecyclerView.Adapter<ItemRecyclerViewAdapter.itemViewHolder>implements Filterable {
    List<Data> mDataListSearched;
    List<Data> mDataList;
    ClickListener mClickListener;




    ItemRecyclerViewAdapter(List<Data> list, ClickListener clickListener) {
        mDataListSearched = list;
        mClickListener = clickListener;
        mDataList = new ArrayList<>();
        mDataList.addAll(list);
    }


    @Override
    public Filter getFilter() {

        return myFilter;
    }

    Filter myFilter = new Filter() {

        //Automatic on background thread
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {

            List<Data> filteredList = new ArrayList<>();

            if (charSequence == null || charSequence.length() == 0) {
                filteredList.addAll(mDataList);
                Log.d("When empty:",Integer.toString(mDataList.size()));
            } else {
                for (Data model: mDataList) {
                    if (model.getType().toLowerCase().contains(charSequence.toString().toLowerCase())||model.getSpec().toLowerCase().contains(charSequence.toString().toLowerCase())) {
                        filteredList.add(model);
                    }
                }
            }

            FilterResults filterResults = new FilterResults();
            filterResults.values = filteredList;
            return filterResults;
        }

        //Automatic on UI thread
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            mDataListSearched.clear();
            mDataListSearched.addAll((Collection<? extends Data>) filterResults.values);
            notifyDataSetChanged();
        }
    };

    public static class itemViewHolder extends RecyclerView.ViewHolder implements View.OnLongClickListener,View.OnClickListener{
        View mView;
        ClickListener clickListener;

        public itemViewHolder(View v,ClickListener clickListener) {
            super(v);
            mView = v;
            this.clickListener = clickListener;
            v.setOnLongClickListener(this);
            v.setOnClickListener(this);

        }

        public void setType(String Type) {
            TextView mType = mView.findViewById(R.id.type_display);
            mType.setText(Type);
        }
        public void setSpec(String Spec) {
            TextView mType = mView.findViewById(R.id.spec_display);
            mType.setText(Spec);
        }

        public void setCount(double Count) {
            String sCount = String.valueOf(Count);
            TextView mCount = mView.findViewById(R.id.count_display);
            mCount.setText(sCount);
        }

        public void setPrice(double Price) {
            String sPrice = Double.toString(Price);
            String finalPrice = "$" + sPrice;
            TextView mPrice = mView.findViewById(R.id.price_display);
            mPrice.setText(finalPrice);
        }
        public void setTotalPrice(double totalPrice) {
            String sPrice = Double.toString(totalPrice);
            String finalPrice = "$" + sPrice;
            //TextView mTotalPrice = mView.findViewById(R.id.totalPrice_display);
            //mTotalPrice.setText(finalPrice);
        }


        @Override
        public void onClick(View v) {

            clickListener.onItemClick(getAdapterPosition());

        }

        @Override
        public boolean onLongClick(View v) {

            clickListener.onItemLongClick(getAdapterPosition());
            return false;
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public itemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View textView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_data_layout, viewGroup, false);
        itemViewHolder vh = new itemViewHolder(textView,mClickListener);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull itemViewHolder vh, int position) {

       Data model = mDataListSearched.get(position);
       //recycler view display
       vh.setType(model.getType());
        vh.setSpec(model.getSpec());
        vh.setCount(model.getCount());
        vh.setPrice(model.getPrice());
        vh.setTotalPrice(model.getTotalPrice());

    }

    @Override
    public int getItemCount() {
        return mDataListSearched.size();

    }
    public interface ClickListener {
        void onItemClick(int position);
        boolean onItemLongClick(int position);
    }


}
