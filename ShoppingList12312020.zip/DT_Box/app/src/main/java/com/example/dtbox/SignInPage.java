package com.example.dtbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignInPage extends AppCompatActivity {
    private EditText sign_in_email;
    private EditText sign_in_password;
    private Button sign_in_button;
    private TextView go_to_sign_up;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_page);
        mAuth = FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser()!=null)
        {
            Intent intent=new Intent(SignInPage.this,ShoppingListOverview.class);
            startActivity(intent);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false); // if you want user to wait for some process to finish,
        builder.setView(R.layout.loading_dialog);
        final AlertDialog dialog = builder.create();
        sign_in_email = (EditText)findViewById(R.id.sign_in_email);
        sign_in_password = (EditText)findViewById(R.id.sign_in_password);
        go_to_sign_up = (TextView)findViewById(R.id.go_to_sign_up);
        sign_in_button = (Button)findViewById(R.id.sign_in_button);
        sign_in_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String userEmail = sign_in_email.getText().toString().trim();
                String userPassword = sign_in_password.getText().toString().trim();
                if(TextUtils.isEmpty(userEmail))
                {
                    sign_in_email.setError("Required Field...");
                    return;
                }
                if(TextUtils.isEmpty(userPassword))
                {
                    sign_in_password.setError("Required Field...");
                    return;
                }
                dialog.show();
                mAuth.signInWithEmailAndPassword(userEmail,userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Intent intent=new Intent(SignInPage.this,ShoppingListOverview.class);
                            startActivity(intent);
                            Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                    }
                });
            }
        });
        go_to_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent=new Intent(SignInPage.this,SignUp.class);
                startActivity(intent);
            }
        });
    }
}
